One of our servers is acting strangely lately.
There are even rumours that it gives out flags if [asked in a right way](https://xkcd.com/424/).

Our forensic team didn't find any backdoors, but when we try to list firewall rules, `nft` just hangs.
The best we could get is this the netlink dump attached in easynft.pcap.

Could you help us figure out what's going on?

P.S. Obviously, the flag was redacted from the dump.
